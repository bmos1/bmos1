﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 NSudoLauncherGUI.rc 使用
//
#define IDD_NSudoDlg                    132
#define IDR_STRING1                     136
#define IDC_UserName                    1000
#define IDC_TokenPrivilege              1001
#define IDC_MandatoryLabel              1004
#define IDC_szPath                      1006
#define IDC_Browse                      1007
#define IDC_Run                         1008
#define IDC_About                       1009
#define IDC_Check_EnableAllPrivileges   1013
#define IDC_SETTINGSGROUPTEXT           1015
#define IDC_WARNINGTEXT                 1016
#define IDC_STATIC_USER                 1017
#define IDC_STATIC_OPEN                 1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
